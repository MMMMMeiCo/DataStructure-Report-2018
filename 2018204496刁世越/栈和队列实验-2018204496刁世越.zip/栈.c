#include<stdlib.h>
#include<stdio.h>

struct Stack{
	int data[2333];
	int top;
	int size;
};

//��ʼ��ջ
void init(struct Stack *S)
{
	S -> top = 0;
	S -> size = 2333;
}

//�ж�ջ��/�� 
int empty(struct Stack *s)
{
	if(s -> top <= 0) return 1;
	else return 0;    
}

int full(struct Stack *s)
{
	if(s -> top >= s -> size) return 1;
	else return 0;	
}

void push(struct Stack *s,int x)
{
	if(!full(s)) s -> data[(s -> top)++] = x;
	else printf("ջ�ռ䲻��\n");
}

int pop(struct Stack *s)
{
	if(!empty(s)) return s -> data[--(s -> top)];
	else
	{
		printf("ջ��\n");
		return 0;
	}
}

int main()
{
	printf("ʵ��3 -- ��ջʵ�ֶ�һ��10������ת��Ϊ16������\n"); 
	int num;
	printf("����һ����:");
	scanf("%d",&num);
	struct Stack s;
	init(&s);
	int tmp;
	printf("����ת���������");
	while(num != 0)
	{
		push(&s,num % 16);
		num = num / 16;
	}
	while(empty(&s) != 1)
	{
		tmp = pop(&s);
		if(tmp == 10) printf("A");
		else if(tmp == 11) printf("B");
		else if(tmp == 12) printf("C");
		else if(tmp == 13) printf("D");
		else if(tmp == 14) printf("E");
		else if(tmp == 15) printf("F");
		else printf("%d",tmp);
	}
	printf("\n");
	return 0;
}


